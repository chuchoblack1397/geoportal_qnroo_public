<?php
    $host="localhost";
	$database="geoporta_reportes_jre"; 
	$usuario="geoporta_jreUser";
	$pass="kfyD#+yP1mS+";
	
	$conexion = new mysqli($host,$usuario,$pass,$database);
	
	if(mysqli_connect_error()){
		echo 'Conexion Fallida : ', mysqli_connect_error();
		exit();
	}
	else{
		echo "<script>console.log('Abriendo conexion');</script>";
	}
?>